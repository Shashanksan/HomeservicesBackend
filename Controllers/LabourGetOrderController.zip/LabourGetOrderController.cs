﻿using Final_Project.Datalayer;
using Final_Project.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace Final_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LabourGetOrderController : ControllerBase
    {
        [HttpGet]
        [Route("labourorder")]
        public  List<LabourGetOrder> LabourGetOrderController01() 
        {

           
          
                List<LabourGetOrder> LabourGetOrderlist = new List<LabourGetOrder>();
                string query = "select  r.username,r.userphonenumber,a.fulladdress from register r inner join AddressUser a on r.userid = a.userid";
                DataTable dt = LabourGetOrdersDataLayer.LabourGetOrders(query);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                LabourGetOrder labourgetorder = new LabourGetOrder();
                labourgetorder.UserName = Convert.ToString(dt.Rows[i]["username"]);
                labourgetorder.UserPhoneNumber = Convert.ToString(dt.Rows[i]["userphonenumber"]);
                labourgetorder.FullAddrress = Convert.ToString(dt.Rows[i]["fulladdress"]);

                LabourGetOrderlist.Add(labourgetorder);

                }
                return LabourGetOrderlist;
      }


    }
}
